import 'package:cloud_firestore/cloud_firestore.dart';

class UserModel {
  final String uid;
  final String name;
  final String email;
  final String role;
  final String phone;
  final String photo;
  final String bloodGroup;
  final String address;
  final DateTime joinedDate;
  final bool active;

  UserModel({
    required this.uid,
    required this.name,
    required this.email,
    required this.role,
    required this.phone,
    this.photo = '',
    this.bloodGroup = '',
    this.address = '',
    required this.joinedDate,
    this.active = true,
  });

  factory UserModel.fromMap(Map<String, dynamic> map) {
    // Handle both Firestore Timestamp and String formats
    DateTime parseDate(dynamic value) {
      if (value == null) return DateTime.now();
      if (value is Timestamp) return value.toDate();
      if (value is String) return DateTime.tryParse(value) ?? DateTime.now();
      return DateTime.now();
    }

    return UserModel(
      uid: map['uid'] ?? '',
      name: map['name'] ?? '',
      email: map['email'] ?? '',
      role: map['role'] ?? 'member',
      phone: map['phone'] ?? '',
      photo: map['photo'] ?? '',
      bloodGroup: map['blood_group'] ?? '',
      address: map['address'] ?? '',
      joinedDate: parseDate(map['joined_date']),
      active: map['active'] ?? true,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'uid': uid,
      'name': name,
      'email': email,
      'role': role,
      'phone': phone,
      'photo': photo,
      'blood_group': bloodGroup,
      'address': address,
      'joined_date': Timestamp.fromDate(joinedDate),
      'active': active,
    };
  }
}