import 'package:cloud_firestore/cloud_firestore.dart';

class MemberModel {
  final String id;
  final String name;
  final String phone;
  final String photo;
  final String role;
  final String position;
  final String bloodGroup;
  final String address;
  final int committeeYear;
  final DateTime joiningDate;
  final bool active;

  MemberModel({
    required this.id,
    required this.name,
    required this.phone,
    this.photo = '',
    required this.role,
    required this.position,
    this.bloodGroup = '',
    this.address = '',
    required this.committeeYear,
    required this.joiningDate,
    this.active = true,
  });

  factory MemberModel.fromMap(Map<String, dynamic> map, String id) {
    // Handle both Firestore Timestamp and String formats
    DateTime parseDate(dynamic value) {
      if (value == null) return DateTime.now();
      if (value is Timestamp) return value.toDate();
      if (value is String) return DateTime.tryParse(value) ?? DateTime.now();
      return DateTime.now();
    }

    return MemberModel(
      id: id,
      name: map['name'] ?? '',
      phone: map['phone'] ?? '',
      photo: map['photo'] ?? '',
      role: map['role'] ?? 'member',
      position: map['position'] ?? '',
      bloodGroup: map['blood_group'] ?? '',
      address: map['address'] ?? '',
      committeeYear: map['committee_year'] ?? DateTime.now().year,
      joiningDate: parseDate(map['joining_date']),
      active: map['active'] ?? true,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'phone': phone,
      'photo': photo,
      'role': role,
      'position': position,
      'blood_group': bloodGroup,
      'address': address,
      'committee_year': committeeYear,
      'joining_date': Timestamp.fromDate(joiningDate),
      'active': active,
    };
  }
}