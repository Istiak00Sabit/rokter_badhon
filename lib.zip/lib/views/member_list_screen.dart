import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../constants/app_colors.dart';
import '../controllers/member_controller.dart';
import '../models/member_model.dart';
import 'add_member_screen.dart';

class MemberListScreen extends StatelessWidget {
  const MemberListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final MemberController controller = Get.put(MemberController());
    final RxString searchQuery = ''.obs;
    final searchController = TextEditingController();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      controller.loadMembers();
    });

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('সদস্য তালিকা'),
        backgroundColor: AppColors.primary,
        foregroundColor: AppColors.white,
        centerTitle: true,
        automaticallyImplyLeading: false,
        actions: [
          Obx(() => Padding(
                padding: const EdgeInsets.only(right: 12),
                child: Center(
                  child: Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: AppColors.white.withValues(alpha: 0.2),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      '${controller.members.length} জন',
                      style: const TextStyle(
                          color: AppColors.white,
                          fontSize: 13,
                          fontWeight: FontWeight.w600),
                    ),
                  ),
                ),
              )),
        ],
      ),
      body: Column(
        children: [
          // Search bar
          Container(
            color: AppColors.white,
            padding: const EdgeInsets.all(16),
            child: TextField(
              controller: searchController,
              onChanged: (val) => searchQuery.value = val.trim(),
              decoration: InputDecoration(
                hintText: 'নাম বা পদবী দিয়ে খুঁজুন...',
                prefixIcon: const Icon(Icons.search,
                    color: AppColors.primary, size: 20),
                suffixIcon: Obx(() => searchQuery.value.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear,
                            color: AppColors.textGrey, size: 18),
                        onPressed: () {
                          searchController.clear();
                          searchQuery.value = '';
                        },
                      )
                    : const SizedBox()),
                filled: true,
                fillColor: AppColors.background,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
                contentPadding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              ),
            ),
          ),

          // Members list
          Expanded(
            child: Obx(() {
              if (controller.isLoading.value) {
                return const Center(
                    child:
                        CircularProgressIndicator(color: AppColors.primary));
              }

              final filtered = controller.members.where((m) {
                return searchQuery.value.isEmpty ||
                    m.name
                        .toLowerCase()
                        .contains(searchQuery.value.toLowerCase()) ||
                    m.position
                        .toLowerCase()
                        .contains(searchQuery.value.toLowerCase());
              }).toList();

              if (filtered.isEmpty) {
                return Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.people_outline,
                          size: 64, color: AppColors.textLight),
                      const SizedBox(height: 16),
                      const Text('কোনো সদস্য পাওয়া যায়নি',
                          style: TextStyle(
                              fontSize: 16, color: AppColors.textGrey)),
                      const SizedBox(height: 8),
                      const Text('নতুন সদস্য যোগ করুন',
                          style: TextStyle(
                              fontSize: 13, color: AppColors.textLight)),
                    ],
                  ),
                );
              }

              // Group by committee year
              final Map<int, List<MemberModel>> groupedByYear = {};
              for (final m in filtered) {
                groupedByYear.putIfAbsent(m.committeeYear, () => []).add(m);
              }
              final sortedYears = groupedByYear.keys.toList()
                ..sort((a, b) => b.compareTo(a));

              return RefreshIndicator(
                onRefresh: controller.loadMembers,
                color: AppColors.primary,
                child: ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: sortedYears.length,
                  itemBuilder: (context, yearIndex) {
                    final year = sortedYears[yearIndex];
                    final yearMembers = groupedByYear[year]!;
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Year header
                        Padding(
                          padding: const EdgeInsets.only(bottom: 10, top: 4),
                          child: Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 12, vertical: 4),
                                decoration: BoxDecoration(
                                  color: AppColors.primary,
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: Text(
                                  '$year সালের কমিটি',
                                  style: const TextStyle(
                                      color: AppColors.white,
                                      fontSize: 13,
                                      fontWeight: FontWeight.bold),
                                ),
                              ),
                              const SizedBox(width: 8),
                              Text('(${yearMembers.length} জন)',
                                  style: const TextStyle(
                                      fontSize: 12,
                                      color: AppColors.textGrey)),
                            ],
                          ),
                        ),
                        ...yearMembers.map((m) => _buildMemberCard(m)),
                        const SizedBox(height: 12),
                      ],
                    );
                  },
                ),
              );
            }),
          ),
        ],
      ),

      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          await Get.to(() => const AddMemberScreen());
          controller.loadMembers();
        },
        backgroundColor: AppColors.primary,
        icon: const Icon(Icons.person_add, color: AppColors.white),
        label: const Text('নতুন সদস্য',
            style: TextStyle(
                color: AppColors.white, fontWeight: FontWeight.bold)),
      ),
    );
  }

  Widget _buildMemberCard(MemberModel member) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            // Avatar
            Container(
              width: 50,
              height: 50,
              decoration: BoxDecoration(
                color: AppColors.primaryLight,
                shape: BoxShape.circle,
                border: Border.all(color: AppColors.primary, width: 1.5),
              ),
              child: Center(
                child: Text(
                  member.name.isNotEmpty ? member.name[0].toUpperCase() : '?',
                  style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: AppColors.primary),
                ),
              ),
            ),
            const SizedBox(width: 14),

            // Info
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(member.name,
                      style: const TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                          color: AppColors.textDark)),
                  const SizedBox(height: 3),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(
                      color: AppColors.primaryLight,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(member.position,
                        style: const TextStyle(
                            fontSize: 11,
                            color: AppColors.primaryDark,
                            fontWeight: FontWeight.w600)),
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      const Icon(Icons.phone_outlined,
                          size: 13, color: AppColors.textGrey),
                      const SizedBox(width: 4),
                      Text(member.phone,
                          style: const TextStyle(
                              fontSize: 13, color: AppColors.textGrey)),
                      if (member.bloodGroup.isNotEmpty) ...[
                        const SizedBox(width: 12),
                        const Icon(Icons.water_drop_outlined,
                            size: 13, color: AppColors.primary),
                        const SizedBox(width: 4),
                        Text(member.bloodGroup,
                            style: const TextStyle(
                                fontSize: 13,
                                color: AppColors.primary,
                                fontWeight: FontWeight.bold)),
                      ],
                    ],
                  ),
                ],
              ),
            ),

            // Call button
            IconButton(
              onPressed: () {
                Get.snackbar('ফোন করুন', member.phone,
                    snackPosition: SnackPosition.BOTTOM,
                    backgroundColor: AppColors.primary,
                    colorText: AppColors.white,
                    duration: const Duration(seconds: 2));
              },
              icon: Container(
                padding: const EdgeInsets.all(8),
                decoration: const BoxDecoration(
                    color: AppColors.primaryLight, shape: BoxShape.circle),
                child: const Icon(Icons.call,
                    color: AppColors.primary, size: 18),
              ),
            ),
          ],
        ),
      ),
    );
  }
}