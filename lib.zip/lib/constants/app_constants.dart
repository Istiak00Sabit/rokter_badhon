class AppConstants {
  // Blood groups
  static const List<String> bloodGroups = [
    'A+', 'A-',
    'B+', 'B-',
    'AB+', 'AB-',
    'O+', 'O-',
  ];

  // Gender
  static const List<String> genders = [
    'পুরুষ',
    'মহিলা',
    'অন্যান্য',
  ];

  // User roles
  static const String roleAdmin = 'admin';
  static const String roleVP = 'vp';
  static const String roleGS = 'gs';
  static const String roleCommittee = 'committee';
  static const String roleMember = 'member';

  // Member types
  static const List<String> memberRoles = [
    'সভাপতি',
    'সহ-সভাপতি',
    'সাধারণ সম্পাদক',
    'সহ-সাধারণ সম্পাদক',
    'কোষাধ্যক্ষ',
    'সাংগঠনিক সম্পাদক',
    'কার্যনির্বাহী সদস্য',
    'সাধারণ সদস্য',
  ];

  // Donation eligibility (days)
  static const int eligibilityDays = 90;

  // Firestore collections
  static const String usersCollection = 'users';
  static const String donorsCollection = 'donors';
  static const String donationsCollection = 'donations';
  static const String membersCollection = 'members';
  static const String requestsCollection = 'requests';
  static const String noticesCollection = 'notices';

  // Address
  static const String upazilla = 'ঘাটাইল';
  static const String district = 'টাঙ্গাইল';

  static const List<String> unions = [
    'ঘাটাইল পৌরসভা',
    'দিঘলকান্দি',
    'লোকেরপাড়',
    'সংগ্রাম',
    'ধলাপাড়া',
    'আনেহলা',
    'দেওপাড়া',
    'রসুলপুর',
    'জামুরকী',
    'পাকুটিয়া',
    'দিগড়',
  ];
}