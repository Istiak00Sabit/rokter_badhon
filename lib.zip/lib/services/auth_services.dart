import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/user_model.dart';
import '../constants/app_constants.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // এখন কে login আছে
  User? get currentUser => _auth.currentUser;

  // Login আছে কিনা
  bool get isLoggedIn => _auth.currentUser != null;

  // Login করা
  Future<Map<String, dynamic>> login({
    required String email,
    required String password,
  }) async {
    try {
      // Firebase এ login করো
      UserCredential credential = await _auth.signInWithEmailAndPassword(
        email: email.trim(),
        password: password.trim(),
      );

      // Firestore থেকে user এর বাকি তথ্য আনো
      DocumentSnapshot doc = await _firestore
          .collection(AppConstants.usersCollection)
          .doc(credential.user!.uid)
          .get();

      if (!doc.exists) {
        return {
          'success': false,
          'message': 'ব্যবহারকারী পাওয়া যায়নি!',
        };
      }

      // User active আছে কিনা check করো
      Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
      if (data['active'] == false) {
        await _auth.signOut();
        return {
          'success': false,
          'message': 'আপনার অ্যাকাউন্ট নিষ্ক্রিয় করা হয়েছে!',
        };
      }

      return {
        'success': true,
        'message': 'সফলভাবে লগইন হয়েছে!',
        'role': data['role'] ?? 'member',
      };
    } on FirebaseAuthException catch (e) {
      return {
        'success': false,
        'message': _getErrorMessage(e.code),
      };
    } catch (e) {
      return {
        'success': false,
        'message': 'কিছু একটা ভুল হয়েছে! আবার চেষ্টা করুন।',
      };
    }
  }

  // Logout করা
  Future<void> logout() async {
    await _auth.signOut();
  }

  // Firestore থেকে current user এর তথ্য আনো
  Future<UserModel?> getCurrentUserData() async {
    try {
      if (currentUser == null) return null;

      DocumentSnapshot doc = await _firestore
          .collection(AppConstants.usersCollection)
          .doc(currentUser!.uid)
          .get();

      if (!doc.exists) return null;

      return UserModel.fromMap(doc.data() as Map<String, dynamic>);
    } catch (e) {
      return null;
    }
  }

  // Firebase error code বাংলায় দেখানো
  String _getErrorMessage(String code) {
    switch (code) {
      case 'user-not-found':
        return 'এই ইমেইলে কোনো অ্যাকাউন্ট নেই!';
      case 'wrong-password':
        return 'পাসওয়ার্ড ভুল হয়েছে!';
      case 'invalid-email':
        return 'ইমেইল ঠিকানা সঠিক নয়!';
      case 'user-disabled':
        return 'এই অ্যাকাউন্ট বন্ধ করা হয়েছে!';
      case 'too-many-requests':
        return 'অনেকবার চেষ্টা করা হয়েছে! কিছুক্ষণ পর আবার চেষ্টা করুন।';
      case 'invalid-credential':
        return 'ইমেইল বা পাসওয়ার্ড ভুল হয়েছে!';
      default:
        return 'লগইন করতে সমস্যা হয়েছে! আবার চেষ্টা করুন।';
    }
  }
}