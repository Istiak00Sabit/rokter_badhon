import 'package:cloud_firestore/cloud_firestore.dart';
import '../constants/app_constants.dart';

class DashboardService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // মোট donor count
  Future<int> getTotalDonors() async {
    try {
      QuerySnapshot snapshot = await _firestore
          .collection(AppConstants.donorsCollection)
          .where('active', isEqualTo: true)
          .get();
      return snapshot.docs.length;
    } catch (e) {
      return 0;
    }
  }

  // মোট member count
  Future<int> getTotalMembers() async {
    try {
      QuerySnapshot snapshot = await _firestore
          .collection(AppConstants.membersCollection)
          .where('active', isEqualTo: true)
          .get();
      return snapshot.docs.length;
    } catch (e) {
      return 0;
    }
  }

  // এই মাসের donation count
  Future<int> getThisMonthDonations() async {
    try {
      DateTime now = DateTime.now();
      DateTime firstDay = DateTime(now.year, now.month, 1);

      QuerySnapshot snapshot = await _firestore
          .collection(AppConstants.donationsCollection)
          .where('date', isGreaterThanOrEqualTo: firstDay.toIso8601String())
          .get();
      return snapshot.docs.length;
    } catch (e) {
      return 0;
    }
  }

  // Active emergency requests
  Future<int> getActiveRequests() async {
    try {
      QuerySnapshot snapshot = await _firestore
          .collection(AppConstants.requestsCollection)
          .where('status', isEqualTo: 'active')
          .get();
      return snapshot.docs.length;
    } catch (e) {
      return 0;
    }
  }

  // Latest notices
  Future<List<Map<String, dynamic>>> getLatestNotices() async {
    try {
      QuerySnapshot snapshot = await _firestore
          .collection(AppConstants.noticesCollection)
          .orderBy('date', descending: true)
          .limit(3)
          .get();

      return snapshot.docs
          .map((doc) => {
                ...doc.data() as Map<String, dynamic>,
                'id': doc.id,
              })
          .toList();
    } catch (e) {
      return [];
    }
  }
}