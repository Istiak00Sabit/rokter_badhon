import 'package:cloud_firestore/cloud_firestore.dart';
import '../constants/app_constants.dart';
import '../models/member_model.dart';

class MemberService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // নতুন সদস্য যোগ করো
  Future<Map<String, dynamic>> addMember(MemberModel member) async {
    try {
      await _firestore
          .collection(AppConstants.membersCollection)
          .add(member.toMap());
      return {'success': true, 'message': 'সদস্য সফলভাবে যোগ করা হয়েছে!'};
    } catch (e) {
      return {'success': false, 'message': 'যোগ করতে সমস্যা হয়েছে: $e'};
    }
  }

  // সব সদস্য আনো
  Future<List<MemberModel>> getAllMembers() async {
    try {
      QuerySnapshot snapshot = await _firestore
          .collection(AppConstants.membersCollection)
          .where('active', isEqualTo: true)
          .orderBy('name')
          .get();
      return snapshot.docs
          .map((doc) =>
              MemberModel.fromMap(doc.data() as Map<String, dynamic>, doc.id))
          .toList();
    } catch (e) {
      return [];
    }
  }

  // বছর অনুযায়ী সদস্য আনো
  Future<List<MemberModel>> getMembersByYear(int year) async {
    try {
      QuerySnapshot snapshot = await _firestore
          .collection(AppConstants.membersCollection)
          .where('active', isEqualTo: true)
          .where('committee_year', isEqualTo: year)
          .orderBy('name')
          .get();
      return snapshot.docs
          .map((doc) =>
              MemberModel.fromMap(doc.data() as Map<String, dynamic>, doc.id))
          .toList();
    } catch (e) {
      return [];
    }
  }
}