import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../models/member_model.dart';
import '../services/member_service.dart';

class MemberController extends GetxController {
  final MemberService _memberService = MemberService();

  // Form fields
  final nameController = TextEditingController();
  final phoneController = TextEditingController();
  final addressController = TextEditingController();

  // Dropdowns
  final RxString selectedBloodGroup = ''.obs;
  final RxString selectedPosition = ''.obs;
  final RxString selectedRole = ''.obs;
  final RxInt selectedYear = DateTime.now().year.obs;

  // Joining date
  final Rx<DateTime> joiningDate = DateTime.now().obs;

  // Loading
  final RxBool isLoading = false.obs;

  // Members list
  final RxList<MemberModel> members = <MemberModel>[].obs;

  // Available years (current year and past 5 years)
  List<int> get availableYears {
    final current = DateTime.now().year;
    return List.generate(6, (i) => current - i);
  }

  @override
  void onClose() {
    nameController.dispose();
    phoneController.dispose();
    addressController.dispose();
    super.onClose();
  }

  void clearForm() {
    nameController.clear();
    phoneController.clear();
    addressController.clear();
    selectedBloodGroup.value = '';
    selectedPosition.value = '';
    selectedRole.value = 'member';
    selectedYear.value = DateTime.now().year;
    joiningDate.value = DateTime.now();
  }

  Future<void> addMember() async {
    if (nameController.text.trim().isEmpty) {
      Get.snackbar('ত্রুটি', 'নাম দিন!',
          backgroundColor: Colors.red, colorText: Colors.white);
      return;
    }
    if (phoneController.text.trim().isEmpty) {
      Get.snackbar('ত্রুটি', 'ফোন নম্বর দিন!',
          backgroundColor: Colors.red, colorText: Colors.white);
      return;
    }
    if (selectedPosition.value.isEmpty) {
      Get.snackbar('ত্রুটি', 'পদবী বেছে নিন!',
          backgroundColor: Colors.red, colorText: Colors.white);
      return;
    }

    try {
      isLoading.value = true;

      final member = MemberModel(
        id: '',
        name: nameController.text.trim(),
        phone: phoneController.text.trim(),
        role: selectedRole.value.isEmpty ? 'member' : selectedRole.value,
        position: selectedPosition.value,
        bloodGroup: selectedBloodGroup.value,
        address: addressController.text.trim(),
        committeeYear: selectedYear.value,
        joiningDate: joiningDate.value,
      );

      final result = await _memberService.addMember(member);

      if (result['success']) {
        clearForm();
        Get.back();
        Get.snackbar(
          'সফল!',
          result['message'],
          backgroundColor: Colors.green,
          colorText: Colors.white,
          snackPosition: SnackPosition.BOTTOM,
        );
      } else {
        Get.snackbar('ত্রুটি', result['message'],
            backgroundColor: Colors.red, colorText: Colors.white);
      }
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> loadMembers() async {
    isLoading.value = true;
    members.value = await _memberService.getAllMembers();
    isLoading.value = false;
  }
}